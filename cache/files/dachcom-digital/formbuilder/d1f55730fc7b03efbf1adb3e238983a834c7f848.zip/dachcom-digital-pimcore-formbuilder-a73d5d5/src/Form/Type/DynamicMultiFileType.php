<?php

/*
 * This source file is available under two different licenses:
 *   - GNU General Public License version 3 (GPLv3)
 *   - DACHCOM Commercial License (DCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 * @copyright  Copyright (c) DACHCOM.DIGITAL AG (https://www.dachcom-digital.com)
 * @license    GPLv3 and DCL
 */

namespace FormBuilderBundle\Form\Type;

use FormBuilderBundle\Configuration\Configuration;
use FormBuilderBundle\Event\Form\FormTypeOptionsEvent;
use FormBuilderBundle\Form\Data\FormData;
use FormBuilderBundle\FormBuilderEvents;
use FormBuilderBundle\Registry\DynamicMultiFileAdapterRegistry;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\CallbackTransformer;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormFactoryInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Contracts\EventDispatcher\EventDispatcherInterface;

class DynamicMultiFileType extends AbstractType
{
    public function __construct(
        protected FormFactoryInterface $formFactory,
        protected Configuration $configuration,
        protected EventDispatcherInterface $eventDispatcher,
        protected DynamicMultiFileAdapterRegistry $dynamicMultiFileAdapterRegistry
    ) {
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'compound'                  => true,
            'max_file_size'             => 0,
            'allowed_extensions'        => [],
            'item_limit'                => 0,
            'submit_as_attachment'      => false,
            'submit_as_admin_deep_link' => false,
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->addEventListener(FormEvents::POST_SET_DATA, [$this, 'handleDynamicMultiFileForm']);
    }

    public function handleDynamicMultiFileForm(FormEvent $event): void
    {
        $adapterFormFieldName = 'adapter';

        $dmfAdapterName = $this->configuration->getConfig('dynamic_multi_file_adapter');
        $dmfAdapter = $this->dynamicMultiFileAdapterRegistry->get($dmfAdapterName);

        $options = $event->getForm()->getConfig()->getOptions();

        $options['compound'] = true;
        $options['auto_initialize'] = false;
        $options['label'] = empty($options['label']) ? false : $options['label'];
        $options['attr']['data-dynamic-multi-file-instance'] = 'true';
        $options['attr']['data-js-handler'] = $dmfAdapter->getJsHandler();

        $rootForm = $event->getForm()->getRoot();
        if ($rootForm->getData() instanceof FormData) {
            $options['attr']['data-field-reference'] = sprintf(
                '%s:%s',
                $rootForm->getData()->getFormDefinition()->getId(),
                $event->getForm()->getName()
            );
        }

        $dmfForm = $this->formFactory->createNamedBuilder(
            $adapterFormFieldName,
            $dmfAdapter->getForm(),
            null,
            $this->dispatchFormTypeOptionsEvent($adapterFormFieldName, $dmfAdapter->getForm(), $options)
        );

        $dmfForm->add('data', HiddenType::class);
        $dmfForm->get('data')->addModelTransformer(new CallbackTransformer(
            function ($identifier) {
                return $identifier === null ? null : json_encode($identifier, JSON_THROW_ON_ERROR);
            },
            function ($identifier) {
                return $identifier === null ? [] : json_decode($identifier, true, 512, JSON_THROW_ON_ERROR);
            }
        ));

        $event->getForm()->add($dmfForm->getForm());
    }

    private function dispatchFormTypeOptionsEvent(string $name, string $type, array $options): array
    {
        $event = new FormTypeOptionsEvent($name, $type, $options);

        $this->eventDispatcher->dispatch($event, FormBuilderEvents::FORM_TYPE_OPTIONS);

        return $event->getOptions();
    }

    public function getBlockPrefix(): string
    {
        return 'form_builder_dynamicmultifile';
    }

    public function getParent(): string
    {
        return HiddenType::class;
    }
}
