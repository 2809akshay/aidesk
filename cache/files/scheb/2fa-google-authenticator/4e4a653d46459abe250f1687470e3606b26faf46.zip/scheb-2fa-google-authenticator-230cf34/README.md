scheb/2fa-google-authenticator
==============================

[![Build Status](https://github.com/scheb/2fa/actions/workflows/ci.yaml/badge.svg?branch=7.x)](https://github.com/scheb/2fa/actions?query=workflow%3ACI+branch%3A7.x)
[![Code Coverage](https://codecov.io/gh/scheb/2fa/branch/7.x/graph/badge.svg)](https://app.codecov.io/gh/scheb/2fa/branch/7.x)
[![Latest Stable Version](https://img.shields.io/packagist/v/scheb/2fa-google-authenticator)](https://packagist.org/packages/scheb/2fa-google-authenticator)
[![Monthly Downloads](https://img.shields.io/packagist/dm/scheb/2fa-google-authenticator)](https://packagist.org/packages/scheb/2fa-google-authenticator/stats)
[![Total Downloads](https://img.shields.io/packagist/dt/scheb/2fa-google-authenticator)](https://packagist.org/packages/scheb/2fa-google-authenticator/stats)
[![License](https://poser.pugx.org/scheb/2fa-google-authenticator/license.svg)](https://packagist.org/packages/scheb/2fa-google-authenticator)

This package extends [scheb/2fa-bundle](https://github.com/scheb/2fa-bundle) with two-factor authentication using Google
Authenticator.

---

This repository is a sub-repository of [scheb/2fa](https://github.com/scheb/2fa) and is **READ ONLY**.

**Please do not submit any Pull Request here.** Use the [main repository](https://github.com/scheb/2fa) instead.

Installation
------------
Please follow the [bundle's installation instructions](https://symfony.com/bundles/SchebTwoFactorBundle/7.x/installation.html).

Documentation
-------------
Documentation can be found on the
[Symfony Bundles Documentation](https://symfony.com/bundles/SchebTwoFactorBundle/7.x/index.html) website.

License
-------
This software is available under the [MIT license](LICENSE).
